# installation:
pip install streamlit

# to start the app
in terminal execute 'streamlit run pepper_scatter_app.py'


# NOTE: 
folder 'pages' is optional and can be removed